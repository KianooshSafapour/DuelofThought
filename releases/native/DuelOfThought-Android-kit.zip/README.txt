# Duel of Thought - Android Kit (Capacitor)

## One-time setup
1. Install Android Studio + JDK 17.
2. Edit capacitor.config.json -> set server.url to the platform URL.
3. npm install && npm run build:project   (creates the native android project)

## Build the APK
    npx cap open android      # Android Studio -> Build > Build APK
    # or headless:
    cd android && ./gradlew assembleDebug
    # APK: android/app/build/outputs/apk/debug/app-debug.apk

Release APK: ./gradlew assembleRelease (configure signing in build.gradle).
