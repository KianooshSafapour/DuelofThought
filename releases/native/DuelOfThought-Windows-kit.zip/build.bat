@echo off
REM Duel of Thought - Windows build (output: dist/Duel of Thought Setup .exe)
echo [1/3] Installing dependencies (one-time)...
call npm install
echo [2/3] Building installer...
call npm run dist -- --win nsis
echo [3/3] Done. See the dist\ folder.
pause
