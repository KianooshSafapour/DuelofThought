const { app, BrowserWindow, shell } = require('electron');
const path = require('path');
const fs = require('fs');

const CONFIG = JSON.parse(fs.readFileSync(path.join(__dirname, 'config.json'), 'utf8'));
const URL = process.env.PLATFORM_URL || CONFIG.url;

function createWindow () {
  const win = new BrowserWindow({
    width: 1360, height: 900,
    minWidth: 360, minHeight: 480,
    backgroundColor: '#09011b',
    autoHideMenuBar: true,
    title: CONFIG.title,
    icon: path.join(__dirname, 'icon.png'),
    webPreferences: { contextIsolation: true, nodeIntegration: false },
  });
  win.loadURL(URL);
  win.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });
}

app.whenReady().then(() => {
  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
