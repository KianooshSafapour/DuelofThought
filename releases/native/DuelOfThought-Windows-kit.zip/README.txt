# Duel of Thought - Windows Kit

1. (Optional) edit config.json -> url (defaults to the deployed platform).
2. Double-click build.bat (needs Node.js 18+).
3. Output: dist/Duel of Thought Setup 0.3.0.exe - installable, shortcuts + uninstaller.
