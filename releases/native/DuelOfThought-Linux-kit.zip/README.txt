# Duel of Thought - Linux Kit

1. (Optional) edit config.json -> url.
2. bash build.sh   (needs Node.js 18+).
3. Output: dist/*.AppImage (portable) and dist/*.deb (installable).
