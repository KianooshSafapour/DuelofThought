#!/usr/bin/env bash
# Duel of Thought - Linux build (output: dist/*.AppImage + *.deb)
set -e
echo "[1/3] Installing dependencies (one-time)..."
npm install
echo "[2/3] Building packages..."
npm run dist -- --linux AppImage deb
echo "[3/3] Done. See the dist/ folder."
