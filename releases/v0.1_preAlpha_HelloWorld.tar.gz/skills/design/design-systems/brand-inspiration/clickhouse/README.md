# ClickHouse Inspired Design System

Design system details have been moved to: https://getdesign.md/clickhouse/design-md

You can also view previews, dark mode examples, and download options on getdesign.md.
